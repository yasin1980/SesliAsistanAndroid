# Sesli Asistan — Android proje paketi

Türkçe sesli komutları tanımak, “Hey Asistan” ifadesiyle komutu etkinleştirmek ve Android'in izin verdiği bazı telefon kontrollerini gerçekleştirmek için hazırlanmış yerel Android Studio projesi.

## Mevcut komutlar

- `Hey Asistan, WhatsApp'ı aç` — başlatıcıda adı eşleşen bir uygulamayı açmayı dener.
- `Hey Asistan, sesi yükselt` / `sesi azalt` / `sesi kapat`
- `Hey Asistan, sesi yüzde 40 yap`
- `Hey Asistan, feneri aç` / `feneri kapat` — kamera izni gerekir.
- `Hey Asistan, ana ekrana dön`
- `Hey Asistan, geri git`
- `Hey Asistan, son uygulamaları göster`
- `Hey Asistan, bildirimleri aç` / `hızlı ayarları aç`
- `Hey Asistan, aşağı kaydır` / `yukarı kaydır` / `sağa kaydır` / `sola kaydır`
- `Hey Asistan, İstanbul'a navigasyon başlat` — Google Maps varsa onu açar.
- `Hey Asistan, dinlemeyi durdur`

## İzin ve kullanım

1. APK kurulunca uygulamayı aç ve mikrofon iznini ver.
2. Ekranda **Dinlemeyi başlat** düğmesine dokun. Android 12+ ve yeni sürümlerde mikrofonlu foreground service uygulama görünürken başlatılır.
3. Ekran hareketleri, geri/ana ekran ve son uygulamalar için **Ekran kontrol iznini aç** düğmesinden Android Erişilebilirlik ayarlarına girip `Sesli Asistan ekran kontrolü` servisini kullanıcı olarak etkinleştir.
4. Fener için **Fener için kamera izni ver** düğmesine bas ve izin ver.
5. Sürekli dinlemeyi durdurmak için bildirimdeki **Durdur** eylemi veya uygulamadaki düğme kullanılabilir.

## Sınırlar

- Konuşma tanıma, cihazdaki Android konuşma tanıma sağlayıcısına bağlıdır; bazı sağlayıcılar internet ister. Bu sürüm gerçek, düşük seviyeli her zaman açık bir hotword DSP kullanmaz. Tanıma servisi her ifadeden sonra yeniden başlatılarak “Hey Asistan” aranır; arka plan/ekran kapalı davranışı üretici ve Android sürümüne göre değişebilir.
- Erişilebilirlik servisi yalnızca kullanıcı ayarlardan etkinleştirirse ekran hareketi yapar. Komutla başka uygulamaları zorla sonlandırma Android tarafından genel olarak engellenir; bu nedenle “kapat” yerine geri/ana ekran gibi desteklenen işlemler uygulanır.
- Android 13+ bildirim izni istenebilir. Mikrofon ve erişilebilirlik izinleri uygulamanın çalışması için açıklanmıştır; kullanıcı istediğinde kapatabilir.
- Bu proje imzalı dağıtım sürümü değildir; CI'da oluşan `app-debug.apk` test amaçlı debug APK'dır.

## APK oluşturma

### GitHub Actions ile (Android SDK'yı yerel bilgisayara kurmadan)

1. Bu ZIP'i açıp içindeki `SesliAsistanAndroid` klasörünün içeriğini yeni bir GitHub deposuna yükle.
2. `Actions` sekmesine gir. `Android APK oluştur` iş akışı push sonrası çalışır; ayrıca **Run workflow** ile elle başlatılabilir.
3. Tamamlandığında iş akışı sayfasının altındaki **Artifacts** bölümünden `SesliAsistan-debug-apk` dosyasını indir ve ZIP'ten çıkar.
4. APK'yı telefona aktar, dosyayı açıp kur. Android bilinmeyen kaynak uyarısı gösterirse yalnızca kullandığın dosya yöneticisine bu kurulum için izin ver.

### Android Studio ile

Android Studio'da klasörü açıp Gradle senkronizasyonunu bekle; ardından `Build > Build APK(s)` seç. Debug APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.

## Doğrulama durumu

Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için burada APK derlemesi veya fiziksel cihaz testi yapılamadı. Proje kaynakları ve APK üretim iş akışı hazırlandı; APK'nın gerçek telefonda denenmesi gerekir. Derlenebilirlik ve cihaz davranışı doğrulanmadan “test edildi” kabul edilmemelidir.
