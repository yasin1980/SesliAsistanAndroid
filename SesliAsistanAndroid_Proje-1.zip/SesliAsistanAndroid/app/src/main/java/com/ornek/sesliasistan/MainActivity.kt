package com.ornek.sesliasistan

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val audioRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 42, 38)
        window.navigationBarColor = android.graphics.Color.rgb(13, 42, 38)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
        } else {
            requestNotificationPermissionIfNeeded()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(28))
            setBackgroundColor(android.graphics.Color.rgb(8, 24, 25))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "SESLİ ASİSTAN"
            textSize = 25f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = .08f
            setPadding(0, dp(24), 0, dp(8))
        }
        val subtitle = TextView(this).apply {
            text = "Telefonunu sesinle yönet"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(174, 207, 196))
            setPadding(0, 0, 0, dp(22))
        }
        status = TextView(this).apply {
            text = "Hazır. Dinlemeyi başlatmak için aşağıya dokun."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(23, 61, 53))
            setPadding(dp(18), dp(22), dp(18), dp(22))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(status, matchWrap())
        content.addView(button("Dinlemeyi başlat") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val serviceIntent = Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_START)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                status.text = "Asistan çalışıyor. ‘Hey Asistan’ de."
            } else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
        })
        content.addView(button("Dinlemeyi durdur") {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            status.text = "Dinleme durduruldu."
        })
        content.addView(button("Fener için kamera izni ver") {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 703)
            } else status.text = "Fener izni zaten verilmiş."
        })
        content.addView(button("Ekran kontrol iznini aç") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(button("Uygulama ayarları / izinler") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        val examples = TextView(this).apply {
            text = "ÖRNEK KOMUTLAR\n\n• Hey Asistan, WhatsApp'ı aç\n• Hey Asistan, sesi yüzde 40 yap\n• Hey Asistan, sesi yükselt\n• Hey Asistan, feneri aç\n• Hey Asistan, ana ekrana dön\n• Hey Asistan, geri git\n• Hey Asistan, son uygulamaları göster\n• Hey Asistan, aşağı kaydır\n• Hey Asistan, İstanbul'a navigasyon başlat\n• Hey Asistan, dinlemeyi durdur"
            textSize = 15f
            setTextColor(android.graphics.Color.rgb(218, 232, 226))
            setPadding(dp(6), dp(22), dp(6), dp(22))
        }
        content.addView(examples)
        val foot = TextView(this).apply {
            text = "Not: Ekran hareketleri için Erişilebilirlik izni gerekir. Ses tanıma kullanılabilir bir Android konuşma tanıma hizmetine bağlıdır."
            textSize = 12f
            setTextColor(android.graphics.Color.rgb(160, 180, 174))
            setPadding(dp(6), dp(10), dp(6), dp(14))
        }
        content.addView(foot)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, dp(54))
        p.topMargin = dp(10)
        layoutParams = p
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            status.text = "Mikrofon izni verildi. Dinlemeyi başlatabilirsin."
            requestNotificationPermissionIfNeeded()
        } else if (requestCode == audioRequest) {
            status.text = "Sesli komutlar için mikrofon izni gerekli."
        } else if (requestCode == 703) {
            status.text = if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) "Fener izni verildi." else "Fener için kamera izni verilmedi."
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 702)
        }
    }
}
