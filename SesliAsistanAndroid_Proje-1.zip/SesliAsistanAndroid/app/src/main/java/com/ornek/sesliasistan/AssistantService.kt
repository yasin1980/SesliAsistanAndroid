package com.ornek.sesliasistan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.text.Normalizer
import java.util.Locale

class AssistantService : Service(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var waitingForCommand = false
    private var running = false
    private var lastCommandAt = 0L
    private var stopAfterSpeech = false
    private lateinit var audio: AudioManager

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this, this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAssistant()
            else -> {
                if (!running) {
                    try {
                        startForeground(NOTIFICATION_ID, notification())
                        running = true
                        if (SpeechRecognizer.isRecognitionAvailable(this)) startListening()
                        else speak("Bu telefonda kullanılabilir bir ses tanıma hizmeti bulunamadı.")
                    } catch (e: Exception) {
                        running = false
                        stopSelf()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { handler.post { if (stopAfterSpeech) stopAssistant() else if (running) startListening() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { handler.post { if (stopAfterSpeech) stopAssistant() else if (running) startListening() } }
            })
        }
    }

    private fun startListening() {
        if (!running || tts?.isSpeaking == true) return
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (running && tts?.isSpeaking != true) handler.postDelayed({ startListening() }, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 700)
                }
                override fun onResults(results: android.os.Bundle?) {
                    val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val phrase = phrases?.firstOrNull().orEmpty()
                    handlePhrase(phrase)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            r.startListening(intent)
        } catch (_: Exception) {
            handler.postDelayed({ if (running) startListening() }, 1500)
        }
    }

    private fun handlePhrase(raw: String) {
        val phrase = normalize(raw)
        if (phrase.isBlank()) { handler.postDelayed({ startListening() }, 400); return }
        val wakeAt = phrase.indexOf("hey asistan")
        if (wakeAt >= 0) {
            val command = phrase.substring(wakeAt + "hey asistan".length).trim(' ', ',', '.', '!', ':')
            if (command.isBlank()) {
                waitingForCommand = true
                speak("Dinliyorum, söyle.")
            } else {
                waitingForCommand = false
                executeCommand(command)
            }
            return
        }
        if (waitingForCommand) {
            waitingForCommand = false
            executeCommand(phrase)
        } else {
            handler.postDelayed({ if (running) startListening() }, 250)
        }
    }

    private fun executeCommand(command: String) {
        lastCommandAt = System.currentTimeMillis()
        when {
            command.contains("dinlemeyi durdur") || command.contains("asistani durdur") -> {
                stopAfterSpeech = true
                speak("Dinlemeyi durduruyorum.")
            }
            command.contains("sesi yukselt") || command.contains("sesi ac") || command == "ses ac" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                speak("Sesi yükselttim.")
            }
            command.contains("sesi azalt") || command.contains("sesi kis") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                speak("Sesi azalttım.")
            }
            command.contains("sessize al") || command.contains("sesi kapat") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                speak("Medya sesini kapattım.")
            }
            command.contains("sesi yuzde") -> setVolumePercent(command)
            command.contains("feneri ac") || command.contains("isigi ac") -> setTorch(true)
            command.contains("feneri kapat") || command.contains("isigi kapat") -> setTorch(false)
            command.contains("ana ekrana") || command == "ana ekran" || command == "eve don" -> accessibility("home", "Ana ekrana dönüyorum.")
            command.contains("geri git") || command == "geri" || command.contains("geri don") -> accessibility("back", "Geri gidiyorum.")
            command.contains("son uygulamalar") || command.contains("acik uygulamalar") -> accessibility("recents", "Son uygulamaları açıyorum.")
            command.contains("bildirimleri ac") || command.contains("bildirim paneli") -> accessibility("notifications", "Bildirimleri açıyorum.")
            command.contains("hizli ayarlar") -> accessibility("quick_settings", "Hızlı ayarları açıyorum.")
            command.contains("asagi kaydir") || command.contains("asagi in") -> accessibility("scroll_down", "Aşağı kaydırıyorum.")
            command.contains("yukari kaydir") || command.contains("yukari cik") -> accessibility("scroll_up", "Yukarı kaydırıyorum.")
            command.contains("sola kaydir") -> accessibility("scroll_left", "Sola kaydırıyorum.")
            command.contains("saga kaydir") -> accessibility("scroll_right", "Sağa kaydırıyorum.")
            command.contains("navigasyon") || command.startsWith("haritada") || command.startsWith("yol tarifi") -> openNavigation(command)
            else -> openAppByName(command)
        }
    }

    private fun accessibility(action: String, successText: String) {
        val service = VoiceControlAccessibilityService.instance
        if (service?.performVoiceAction(action) == true) speak(successText)
        else speak("Bu işlem için ayarlardan Sesli Asistan ekran kontrol iznini açmalısın.")
    }

    private fun setVolumePercent(command: String) {
        val percent = Regex("(\\d{1,3})").find(command)?.value?.toIntOrNull()
        if (percent == null) { speak("Yüzde kaç ses istediğini söyle."); return }
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val value = (max * percent.coerceIn(0, 100) / 100f).toInt()
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, AudioManager.FLAG_SHOW_UI)
        speak("Medya sesini yüzde ${percent.coerceIn(0, 100)} yaptım.")
    }

    private fun setTorch(enabled: Boolean) {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { speak("Bu telefonda fener bulunamadı."); return }
            manager.setTorchMode(id, enabled)
            speak(if (enabled) "Feneri açtım." else "Feneri kapattım.")
        } catch (_: SecurityException) { speak("Fener izni veya kamera erişimi kullanılamıyor.") }
        catch (_: Exception) { speak("Fener şu anda kontrol edilemiyor.") }
    }

    private fun openNavigation(command: String) {
        val destination = command
            .replace("navigasyon baslat", "").replace("navigasyonu baslat", "")
            .replace("navigasyon ac", "").replace("haritada", "").replace("yol tarifi", "")
            .replace("git", "").replace("baslat", "").trim(' ', ',', '.')
        if (destination.isBlank()) { speak("Nereye gitmek istediğini söyle. Örneğin İstanbul'a navigasyon başlat."); return }
        try {
            val uri = android.net.Uri.parse("google.navigation:q=" + android.net.Uri.encode(destination))
            val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            startActivity(intent)
            speak("Navigasyonu açıyorum: $destination")
        } catch (_: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=" + android.net.Uri.encode(destination))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                speak("Haritayı açıyorum: $destination")
            } catch (_: Exception) { speak("Harita uygulaması bulunamadı.") }
        }
    }

    private fun openAppByName(command: String) {
        val target = command.replace("uygulamasini ac", "").replace("uygulamayi ac", "")
            .replace("uygulamasini", "").replace("uygulama", "").replace(" ac", "").trim()
        if (target.isBlank()) { speak("Hangi uygulamayı açmamı istiyorsun?"); return }
        try {
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            val match = apps.firstOrNull {
                val label = normalize(it.loadLabel(packageManager).toString())
                label.length >= 3 && command.contains(label)
            } ?: apps.firstOrNull { normalize(it.loadLabel(packageManager).toString()).contains(target) }
                ?: apps.firstOrNull { normalize(it.activityInfo.packageName).contains(target.replace(" ", "")) }
            val launch = match?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                speak("${match.loadLabel(packageManager)} açılıyor.")
            } else speak("$target adlı uygulamayı bulamadım. Uygulama adını tekrar söyle.")
        } catch (_: Exception) { speak("Uygulama açılamadı.") }
    }

    private fun normalize(value: String): String {
        return Normalizer.normalize(value.lowercase(Locale("tr", "TR")), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
            .replace(Regex("\\s+"), " ").trim()
    }

    private fun speak(message: String) {
        if (!ttsReady || tts == null) {
            handler.postDelayed({ if (running) startListening() }, 1200)
            return
        }
        try { tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "reply-${System.currentTimeMillis()}") }
        catch (_: Exception) { handler.postDelayed({ if (running) startListening() }, 900) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Sesli Asistan", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Sesli komut dinleme hizmeti"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Sesli Asistan aktif")
                .setContentText("‘Hey Asistan’ komutunu bekliyor")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open).setOngoing(true)
                .addAction(Notification.Action.Builder(null, "Durdur", stop).build()).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Sesli Asistan aktif").setContentText("‘Hey Asistan’ komutunu bekliyor")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(open).setOngoing(true).build()
        }
    }

    private fun stopAssistant() {
        running = false
        waitingForCommand = false
        stopAfterSpeech = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.ornek.sesliasistan.START"
        const val ACTION_STOP = "com.ornek.sesliasistan.STOP"
        private const val CHANNEL_ID = "voice_assistant_channel"
        private const val NOTIFICATION_ID = 4201
    }
}
